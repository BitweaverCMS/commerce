<?php
$template_name = 'CSS Layout';
$template_version = 'Version 1.0';
$template_author = 'Zen Cart Team';
$template_description = 'This template can be easily modified using only the style sheet to change colors, fonts, and even the layout. Two files are most important: stylesheet.css and style_layout.css.';
$template_screenshot = 'scr_zencss.jpg';
?>